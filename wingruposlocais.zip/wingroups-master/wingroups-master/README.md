# wingroups
Retrieve content of local groups.

User can customize the list of targeted groups by providing the SIDs of the groups within the powershell script.